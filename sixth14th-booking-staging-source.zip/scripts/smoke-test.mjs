const baseUrl = process.env.SMOKE_BASE_URL || "http://localhost:4173";
const auth = process.env.SMOKE_USERNAME && process.env.SMOKE_PASSWORD
  ? `Basic ${Buffer.from(`${process.env.SMOKE_USERNAME}:${process.env.SMOKE_PASSWORD}`).toString("base64")}`
  : null;

const checks = [
  ["health", "GET", "/api/health"],
  ["config", "GET", "/api/config"],
  ["status", "GET", "/api/staging/status"],
  ["available quote", "POST", "/api/quote", { arrival: "2026-06-15", departure: "2026-06-17", guests: 2 }],
  ["blocked quote", "POST", "/api/quote", { arrival: "2026-05-15", departure: "2026-05-17", guests: 2 }, 400]
];

let failures = 0;

for (const [name, method, path, body, expectedStatus = 200] of checks) {
  const response = await fetch(`${baseUrl}${path}`, {
    method,
    headers: {
      ...(auth ? { authorization: auth } : {}),
      ...(body ? { "content-type": "application/json" } : {})
    },
    body: body ? JSON.stringify(body) : undefined
  });
  const passed = response.status === expectedStatus;
  console.log(`${passed ? "PASS" : "FAIL"} ${name}: ${response.status}`);
  if (!passed) failures += 1;
}

if (failures) {
  process.exit(1);
}
