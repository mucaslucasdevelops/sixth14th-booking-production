export async function syncLodgifyData(store, options) {
  const apiKey = options.apiKey;
  if (!apiKey) {
    throw new Error("Lodgify API key is not configured.");
  }

  const now = options.now || new Date();
  const months = Number(options.months || 12);
  const apiBaseUrl = String(options.apiBaseUrl || "https://api.lodgify.com/v2").replace(/\/+$/, "");
  const fetchImpl = options.fetchImpl || fetch;

  const lodgifyBookings = await fetchLodgifyBookings({ apiKey, apiBaseUrl, fetchImpl });
  const lodgifyReservations = buildBookingSummaries(lodgifyBookings, now);
  const availabilityBlocks = await fetchAvailabilityBlocks({ apiKey, apiBaseUrl, fetchImpl, months, now });

  const previousReservations = Array.isArray(store.reservations) ? store.reservations : [];
  const previousAvailabilityBlocks = Array.isArray(store.availabilityBlocks) ? store.availabilityBlocks : [];

  return {
    store: {
      ...store,
      reservations: [
        ...previousReservations.filter((reservation) => reservation.source !== "lodgify"),
        ...lodgifyReservations
      ],
      manualBlocks: Array.isArray(store.manualBlocks) ? store.manualBlocks : [],
      availabilityBlocks: [
        ...previousAvailabilityBlocks.filter((block) => block.source !== "lodgify_availability"),
        ...availabilityBlocks
      ],
      lodgifyLastSyncedAt: now.toISOString()
    },
    importedBookings: lodgifyReservations.length,
    availabilityBlocks: availabilityBlocks.length,
    syncedAt: now.toISOString()
  };
}

async function fetchLodgifyBookings({ apiKey, apiBaseUrl, fetchImpl }) {
  const url = new URL(`${apiBaseUrl}/reservations/bookings`);
  url.searchParams.set("size", "100");
  url.searchParams.set("includeExternal", "true");
  url.searchParams.set("stayFilter", "Upcoming");
  url.searchParams.set("trash", "false");
  return fetchLodgifyJson(fetchImpl, url, apiKey, "Lodgify booking import");
}

function buildBookingSummaries(lodgify, now) {
  const reservations = [];

  for (const booking of lodgify.items || []) {
    const status = String(booking.status || "").toLowerCase();
    const shouldBlock =
      !booking.is_deleted &&
      !["declined", "canceled", "cancelled"].includes(status) &&
      (booking.is_unavailable || ["booked", "tentative", "open"].includes(status));

    if (!shouldBlock) continue;

    reservations.push({
      id: `lodgify-${booking.id}`,
      source: "lodgify",
      externalId: String(booking.id),
      arrival: booking.arrival,
      departure: booking.departure,
      status: `lodgify_${status || "hold"}`,
      paymentStatus: booking.amount_due > 0 ? "lodgify_balance_due" : "lodgify_paid_or_external",
      guest: {
        name: booking.guest?.name || "Imported Lodgify booking",
        email: "",
        phone: "",
        guests: booking.rooms?.[0]?.people || 1,
        notes: "Guest contact details are intentionally not imported."
      },
      quote: {
        arrival: booking.arrival,
        departure: booking.departure,
        nights: nightsBetween(booking.arrival, booking.departure),
        currency: booking.currency_code || "USD",
        lineItems: [],
        subtotal: booking.total_amount || 0,
        taxes: booking.subtotals?.taxes || 0,
        total: booking.total_amount || 0,
        depositDue: 0,
        balanceDue: booking.amount_due || 0,
        checkInTime: normalizeTime(booking.check_in?.time),
        checkOutTime: normalizeTime(booking.check_out?.time)
      },
      stripeCheckoutSessionId: null,
      stripePaymentIntentId: null,
      amountPaid: booking.amount_paid || 0,
      createdAt: booking.created_at || now.toISOString(),
      updatedAt: now.toISOString()
    });
  }

  return reservations;
}

async function fetchAvailabilityBlocks({ apiKey, apiBaseUrl, fetchImpl, months, now }) {
  const today = startOfUtcDay(now);
  const finalDay = addMonths(today, months);
  const blocks = [];

  for (let cursor = today; cursor < finalDay; cursor = addDays(cursor, 60)) {
    const chunkEnd = new Date(Math.min(addDays(cursor, 59).getTime(), finalDay.getTime()));
    const url = new URL(`${apiBaseUrl}/availability`);
    url.searchParams.set("start", dateToIso(cursor));
    url.searchParams.set("end", dateToIso(chunkEnd));

    const availability = await fetchLodgifyJson(fetchImpl, url, apiKey, "Lodgify availability sync");
    for (const calendar of availability || []) {
      for (const period of calendar.periods || []) {
        if (Number(period.available) > 0) continue;
        const bookingIds = (period.bookings || []).map((booking) => String(booking.id)).filter(Boolean);
        const start = period.start;
        const displayEnd = period.end;
        const end = addDaysIso(period.end, 1);
        blocks.push({
          id: `lodgify-availability-${start}-${displayEnd}-${bookingIds.join("-") || "blocked"}`,
          source: "lodgify_availability",
          start,
          end,
          displayEnd,
          reason: availabilityReason(period, bookingIds),
          bookingIds,
          createdAt: now.toISOString()
        });
      }
    }
  }

  return mergeAvailabilityBlocks(blocks);
}

async function fetchLodgifyJson(fetchImpl, url, apiKey, label) {
  const response = await fetchImpl(url, { headers: lodgifyHeaders(apiKey) });
  const text = await response.text();
  if (!response.ok) {
    throw new Error(`${label} failed: ${response.status} ${text}`);
  }
  return text ? JSON.parse(text) : null;
}

function mergeAvailabilityBlocks(blocks) {
  const sorted = [...blocks].sort((a, b) => a.start.localeCompare(b.start) || a.end.localeCompare(b.end));
  const merged = [];

  for (const block of sorted) {
    const previous = merged[merged.length - 1];
    const canMerge =
      previous &&
      previous.end >= block.start &&
      previous.reason === block.reason &&
      sameIds(previous.bookingIds, block.bookingIds);

    if (canMerge) {
      previous.end = maxIso(previous.end, block.end);
      previous.displayEnd = maxIso(previous.displayEnd, block.displayEnd);
      continue;
    }
    merged.push({ ...block });
  }

  return merged;
}

function availabilityReason(period, bookingIds) {
  if (bookingIds.length) return "Synced Lodgify booking";
  if (period.closed_period) return "Synced Lodgify closed period";
  if ((period.channel_calendars || []).length) return "Synced channel calendar";
  return "Synced Lodgify unavailable";
}

function lodgifyHeaders(apiKey) {
  return {
    accept: "application/json",
    "accept-language": "en",
    "x-apikey": apiKey
  };
}

function nightsBetween(start, end) {
  return Math.round((new Date(`${end}T00:00:00Z`) - new Date(`${start}T00:00:00Z`)) / 86400000);
}

function normalizeTime(value) {
  if (!value) return "";
  const [hour, minute] = value.split(":").map(Number);
  const suffix = hour >= 12 ? "PM" : "AM";
  const displayHour = hour % 12 || 12;
  return `${displayHour}:${String(minute || 0).padStart(2, "0")} ${suffix}`;
}

function startOfUtcDay(date) {
  return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
}

function addDays(date, days) {
  const next = new Date(date);
  next.setUTCDate(next.getUTCDate() + days);
  return next;
}

function addMonths(date, months) {
  const next = new Date(date);
  next.setUTCMonth(next.getUTCMonth() + months);
  return next;
}

function addDaysIso(iso, days) {
  return dateToIso(addDays(new Date(`${iso}T00:00:00Z`), days));
}

function dateToIso(date) {
  return date.toISOString().slice(0, 10);
}

function maxIso(a, b) {
  return a > b ? a : b;
}

function sameIds(a = [], b = []) {
  return a.length === b.length && a.every((id, index) => id === b[index]);
}
